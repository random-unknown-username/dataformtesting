
const fs = require("fs");
const path = require("path");

function write(name, data) {
  fs.writeFileSync(path.join(__dirname, name), data);
}

function trySymlink(target, name) {
  try {
    const link = path.join(__dirname, name);
    try { fs.unlinkSync(link); } catch (_) {}
    fs.symlinkSync(target, link, "dir");
    write(name + "_RESULT.txt", "SYMLINK_OK -> " + target + "\n");
  } catch (e) {
    write(name + "_ERROR.txt", e.name + ": " + e.message + "\n");
  }
}

try {
  write("POSTINSTALL_RAN.txt", "POSTINSTALL_RAN\n");

  // package dir is repo/node_modules/df-script-canary/
  // repo root is ../..
  // repo .git is ../../.git
  fs.writeFileSync(path.resolve(__dirname, "../../NPM_POSTINSTALL_ROOT_CANARY.txt"), "ROOT_WRITE_OK\n");

  trySymlink("../../.git", "gitdir_script");
  trySymlink("../..", "reporoot_script");
  trySymlink("/etc", "etc_script");
} catch (e) {
  write("POSTINSTALL_TOP_ERROR.txt", e.name + ": " + e.message + "\n");
}
