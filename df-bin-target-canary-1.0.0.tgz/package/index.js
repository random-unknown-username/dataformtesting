#!/usr/bin/env node
console.log('DF_NORMAL_BIN');
