module.exports = { ok: true, marker: 'REAL_INDEX_FILE' };
