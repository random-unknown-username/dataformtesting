#!/usr/bin/env node
console.log('DF_BIN_CANARY');
